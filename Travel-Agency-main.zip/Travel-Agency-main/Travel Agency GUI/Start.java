import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Start {

    public static void main(String[] args) {

        Welcome frame = new Welcome();
        frame.setVisible(true);
    }
}
